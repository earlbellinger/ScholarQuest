# ScholarQuest
Academia gamified! Gain experience, unlock achievements, and level up when you contribute to humanity's quest for knowledge by publishing scholarly articles. 

It's a chrome extension that tracks the data on your Google Scholar profile page and gives achievements when you reach certain milestones. 

[**Play here!**](https://chrome.google.com/webstore/detail/scholarquest/mgkokkhkifdllajadfkmbjkchhcignml) <br /> <sub>URL: https://chrome.google.com/webstore/detail/scholarquest/mgkokkhkifdllajadfkmbjkchhcignml</sub>

Screenshot:

<p align="center" width="100%">
    <img src="assets/images/ScholarQuest.png" alt="ScholarQuest example"> 
</p>