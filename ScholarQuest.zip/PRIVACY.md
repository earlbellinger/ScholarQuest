# PRIVACY POLICY

When this extension is installed, it will open your personal Google Scholar profile page and read the public data that you have displayed on it: your name, your Google Scholar profile ID number, the number of papers you have written, and the number of citations each of those papers has received. 

This will be used to recognize when you are on your own page, and to determine whether you have unlocked any new achievements. This information will be updated each time you visit your own Google Scholar profile.

This information will be stored only within your Google Chrome user storage. It will not be shared with the developer nor with any other users. 
